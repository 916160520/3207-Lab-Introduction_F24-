# 3207-Lab-Introduction_F24
In this lab, you will be learning about git and some of the features of git and GitHub. A part of the lab will be to clone this repository and and then make changes to the repository. (Do not work in this repository).
The attached simple source file print_random.c is to be modified by you to include a function that implements the randchar() function.
See the instructions in the GitHW file
